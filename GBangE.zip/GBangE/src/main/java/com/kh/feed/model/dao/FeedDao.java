package com.kh.feed.model.dao;

public class FeedDao {

}
