package com.kh.feed.model.service;

public class FeedService {

}
