package com.kh.marathon.model.dao;

public class MarathonDao {

}
