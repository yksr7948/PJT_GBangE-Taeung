package com.kh.marathon.model.service;

public class MarathonService {

}
