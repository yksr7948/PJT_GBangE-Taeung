package com.kh.member.model.dao;

public class MemberDao {

}
