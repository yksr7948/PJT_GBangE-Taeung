package com.kh.member.model.service;

public class MemberService {

}
