package com.kh.notice.model.dao;

public class NoticeDao {

}
