package com.kh.qna.model.dao;

public class QnADao {

}
