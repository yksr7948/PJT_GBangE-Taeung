package com.kh.qna.model.service;

public class QnAService {

}
