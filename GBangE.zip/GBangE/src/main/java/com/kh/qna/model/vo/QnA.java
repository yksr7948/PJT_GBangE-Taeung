package com.kh.qna.model.vo;

public class QnA {

}
