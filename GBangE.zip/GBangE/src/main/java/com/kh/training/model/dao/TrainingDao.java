package com.kh.training.model.dao;

public class TrainingDao {

}
