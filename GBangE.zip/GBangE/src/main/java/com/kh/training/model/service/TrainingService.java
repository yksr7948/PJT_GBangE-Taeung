package com.kh.training.model.service;

public class TrainingService {

}
