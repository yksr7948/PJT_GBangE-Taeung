package com.kh.training.model.vo;

public class Training {
	private int trainingNo;
	private String trainingName;
	private String trainingContent;
}
